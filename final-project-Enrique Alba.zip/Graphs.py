import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def create_graph():
    option = var.get()  # Get the selected option
    plt.clf()  # Clear the previous plot
    
    
                            #KNN
    #1True Positive Rate (Sensitivity): 0.8333333333333334
    #False Positive Rate: 0.14285714285714285
    #F1 Score: 0.7692307692307692
    
    #2True Positive Rate (Sensitivity): 0.8333333333333334
    #False Positive Rate: 0.07142857142857142
    #F1 Score: 0.8333333333333334
    
    #3True Positive Rate (Sensitivity): 1.0
    #False Positive Rate: 0.0
    #F1 Score: 1.0
    
    #4True Positive Rate (Sensitivity): 0.8461538461538461
    #False Positive Rate: 0.2857142857142857
    #F1 Score: 0.8461538461538461
    
    #5True Positive Rate (Sensitivity): 0.3333333333333333
    #False Positive Rate: 0.0
    #F1 Score: 0.5
    
    #6True Positive Rate (Sensitivity): 0.9230769230769231
    #False Positive Rate: 0.14285714285714285
    #F1 Score: 0.9230769230769231
    
    #7True Positive Rate (Sensitivity): 1.0
    #False Positive Rate: 0.09090909090909091
    #F1 Score: 0.9473684210526316
    
    ######################################################################
    
                            #LinearSVC
    #1True Positive Rate (Sensitivity): 0.2
    #False Positive Rate: 0.1
    #F1 Score: 0.30769230769230765
    
    #2True Positive Rate (Sensitivity): 1.0
    #False Positive Rate: 0.2857142857142857
    #F1 Score: 0.7499999999999999
    
    #3True Positive Rate (Sensitivity): 0.7
    #False Positive Rate: 0.0
    #F1 Score: 0.8235294117647058
    
    #4True Positive Rate (Sensitivity): 0.07692307692307693
    #False Positive Rate: 0.14285714285714285
    #F1 Score: 0.13333333333333336
    
    #5True Positive Rate (Sensitivity): 0.1111111111111111
    #False Positive Rate: 0.09090909090909091
    #F1 Score: 0.1818181818181818
    
    #6True Positive Rate (Sensitivity): 0.07692307692307693
    #False Positive Rate: 0.14285714285714285
    #F1 Score: 0.13333333333333336
    
    #7True Positive Rate (Sensitivity): 0.7777777777777778
    #False Positive Rate: 0.0
    #F1 Score: 0.8750000000000001
    
    ####################################################################
    
                                #Kernal​ SVMachine
    #1True Positive Rate (Sensitivity): 0.8888888888888888
    #False Positive Rate: 0.09090909090909091
    #F1 Score: 0.888888888888888
    
    #2True Positive Rate (Sensitivity): 0.5
    #False Positive Rate: 0.0
    #F1 Score: 0.6666666666666666
    
    
    #3True Positive Rate (Sensitivity): 0.9
    #False Positive Rate: 0.0
    #F1 Score: 0.9473684210526316
    
    
    #4True Positive Rate (Sensitivity): 0.7692307692307693
    #False Positive Rate: 0.2857142857142857
    #F1 Score: 0.8
    
    
    #5True Positive Rate (Sensitivity): 0.3333333333333333
    #False Positive Rate: 0.09090909090909091
    #F1 Score: 0.46153846153846156
    
    
    #6True Positive Rate (Sensitivity): 0.8461538461538461
    #False Positive Rate: 0.0
    #F1 Score: 0.9166666666666666
    
    
    #True Positive Rate (Sensitivity): 0.8888888888888888
    #False Positive Rate: 0.09090909090909091
    #F1 Score: 0.8888888888888888
    
    
    #
    
    
    #
    
    if option == 1:  # True Positive Rate
        x = [1, 2, 3, 4, 5, 6, 7]#name of data
        y = [0.83, 0.83, 1.0, .84,  0.33 , 0.92 , 1.0]#score
        names = [' ', ' ', ' ', 'K Nearest Neighbor', ' ', ' ', ' ']
        plt.plot(x, y, marker='o', linestyle='-', color='b')
        
        x2 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 2
        y2 = [0.2, 1.0, 0.7, 0.07,0.11, 0.07, 0.77]  # y values for line 2
        names2 = [' ', ' ', ' ', 'Linear SVC', ' ', ' ', ' ']  # names for line 2
        plt.plot(x2, y2, marker='o', linestyle='-', color='r', label='Line 2')  # Plot line 2
        
        x3 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 3
        y3 = [0.88,0.5 ,0.9 ,0.76 ,0.33 ,0.84 ,0.88]  # y values for line 3
        names3 = [' ', ' ', ' ', 'Kernal​ SVMachine', ' ', ' ', ' ']  # names for line 3
        plt.plot(x3, y3, marker='o', linestyle='-', color='g', label='Line 3')  # Plot line 3
        
        plt.title('True Positive Rate')
        plt.xlabel('X-axis')
        plt.ylabel('True Positive Rate')
        
        # Add labels for each point
        for i, name in enumerate(names):
            plt.text(x[i], y[i], name, ha='right', va='bottom')  # Adjust text position
    
        for i, name in enumerate(names2):
            plt.text(x2[i], y2[i], name, ha='right', va='bottom')  # Adjust text position for line 2
            
        for i, name in enumerate(names3):
            plt.text(x3[i], y3[i], name, ha='right', va='bottom')  # Adjust text position for line 2    

    elif option == 2:  # False Positive Rate
        x = [1, 2, 3, 4, 5, 6, 7]
        y = [0.14, 0.07, 0.0, 0.28, 0.0 , 0.14 , 0.09]
        names = [' ', ' ', ' ', 'K Nearest Neighbor', ' ', ' ', ' ']
        plt.plot(x, y, marker='o', linestyle='-', color='b')
        
        x2 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 2
        y2 = [0.1, 0.28,  0.0, 0.14, 0.09, 0.14,  0.0]  # y values for line 2
        names2 = [' ', ' ', ' ', 'Linear SVC', ' ', ' ', ' ']  # names for line 2
        plt.plot(x2, y2, marker='o', linestyle='-', color='r', label='Line 2')  # Plot line 2

        x3 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 3
        y3 = [0.09, 0.0,  0.0,0.28 , 0.09,0.0 ,0.09]  # y values for line 3
        names3 = [' ', ' ', ' ', 'Kernal​ SVMachine', ' ', ' ', ' ']  # names for line 3
        plt.plot(x3, y3, marker='o', linestyle='-', color='g', label='Line 3')  # Plot line 3
        
        plt.title('False Positive Rate')
        plt.xlabel('X-axis')
        plt.ylabel('False Positive Rate')
        
        # Add labels for each point
        for i, name in enumerate(names):
            plt.text(x[i], y[i], name, ha='right', va='bottom')  # Adjust text position
    
    elif option == 3:  # F1 Score
        x = [1, 2, 3, 4, 5, 6, 7]
        y = [0.76, 0.83, 1.0,0.84, 0.5 , 0.92 , 0.94]
        names = [' ', ' ', ' ', 'K Nearest Neighbor', ' ', ' ', ' ']
        plt.plot(x, y, marker='o', linestyle='-', color='b')
        
        x2 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 2
        y2 = [0.30, 0.74, 0.82, 0.13, 0.18, 0.9, 0.87]  # y values for line 2
        names2 = [' ', ' ', ' ', 'Linear SVC', ' ', ' ', ' ']  # names for line 2
        plt.plot(x2, y2, marker='o', linestyle='-', color='r', label='Line 2')  # Plot line 2

        x3 = [1, 2, 3, 4, 5, 6, 7]  # x values for line 3
        y3 = [0.88,0.66 ,0.94 ,0.8 ,0.46 ,0.91 ,0.88 ]  # y values for line 3
        names3 = [' ', ' ', ' ', 'Kernal​ SVMachine', ' ', ' ', ' ']  # names for line 3
        plt.plot(x3, y3, marker='o', linestyle='-', color='g', label='Line 3')  # Plot line 3
        
        
        plt.title('F1 Score')
        plt.xlabel('X-axis')
        plt.ylabel('F1 Score')
        
        # Add labels for each point
        for i, name in enumerate(names):
            plt.text(x[i], y[i], name, ha='right', va='bottom')  # Adjust text position
    
    
    # Adjust layout
    plt.tight_layout() 
    canvas = FigureCanvasTkAgg(plt.gcf(), master=window)  
    canvas.draw()
    canvas.get_tk_widget().pack()
    
    

#main window
window = tk.Tk()
window.title("Matplotlib Plot in Tkinter")
window.geometry("500x400")

#label for options
label = ttk.Label(window, text="Select an option:")
label.pack()

#variable to store the selected option
var = tk.IntVar()

#update graph when option  selected
def on_select():
    create_graph()

#Create radio buttons for options
options = [("True Positive Rate", 1), ("False Positive Rate", 2), ("F1 Score", 3)]
for text, value in options:
    rb = ttk.Radiobutton(window, text=text, variable=var, value=value, command=on_select)
    rb.pack()

#Start the GUI
window.mainloop()
